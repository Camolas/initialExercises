#include <stdio.h>
int main (void)
{
  int s = 0, k = 1; //s deve ser incializado aqui
  while (k < 1000) { //erro aqui!
    s = s + k;
    k = k + 2;
  }
  printf("soma e %d\n", s);
  return 0;
}
