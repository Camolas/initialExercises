#include <stdio.h>
int main (void)
{
  int a, b, r;
  printf("Introduz a e b:\n");
  scanf("%d %d", &a, &b);
  while (a != 0 )
    {
      r = b % a;
      b = a;
      a = r;
    }
  if (b == 1)
    printf("Os numeros inseridos sao primos entre si\n");
  else
    printf("Os numeros possuem fatores comuns\n");
  return 0;
}
