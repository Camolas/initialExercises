#include <stdio.h>
int main (void)
{
  int a, b, r;
  printf("Introduz a e b:\n");
  scanf("%d %d", &a, &b);
  while (a != 0 )
    {
      r = b % a;
      b = a;
      a = r;
    }
  printf("mdc = %d\n", b);
  return 0;
}
