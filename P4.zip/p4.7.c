#include <stdio.h>

int multiplo (int x, int y);

int main (void)
{
  int x, y;
  scanf("%d %d", &x, &y);
  while(x != 0 || y != 0)
    {
      if(multiplo(x,y))
	printf("%d e %d são múltiplos\n", x, y);
      scanf("%d %d", &x, &y);
    }

  return 0;
}

int multiplo (int x, int y)
{
  if (x == 0 || y == 0)
    return 1;
  else if (x % y == 0 || y % x == 0)
    return 1;
  return 0;
}
