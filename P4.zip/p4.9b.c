#include <stdio.h>

int main (void)
{
  int n, max = 1000, min = 0, r, c = 0;
  printf("Insira n: ");
  scanf("%d", &n);
  r = 0;
  while (r != n) 
    {
      c++;     
      if (r > n)
	max = r - 1;
      else if (r < n)
	min = r + 1; 
      r = (max + min)/2;     
    }

  printf("n é %d\nganhei em %d tentativas\n", r, c);

  return 0;
}
