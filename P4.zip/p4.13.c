#include <stdio.h>

int main (void)
{
  char c, n=0;
  while ((c=getchar()) != EOF)
    {
      if (c != '\n')
	n++;
      else
	continue;
      
      if (n % 80 == 0)
	{
	  putchar(c);
	  putchar('\n');
	}
      else
	putchar(c);
    }

  return 0;
}
