#include <stdio.h>
#include <math.h>

float f_a(float x);
float f_b(float x);
float fatorial(int x, int n);

int main (void)
{
  float x;
  for (x = 0.0; x <= 45.0; x += 5)
    printf("fa(%f) = %f\n", (x/180.0) * M_PI, f_a((x/180.0) * M_PI));

  for (x = 0.1; x <= 1.0; x += 0.05)
    printf("fb(%f) = %f\n", x, f_b(x));

  return 0;
}

float f_a(float x)
{
  return cos(sqrt(x) + 1);
}

float f_b(float x)
{
  return pow(-1.0, 1.0/x) / fatorial(100, x*100);
}

float fatorial(int x, int n)
{
  float r = x;
  while(--x >= n) r=r*x;
  return r;
}
