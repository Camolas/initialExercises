#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main (void)
{
  int n, r, c = 0;
  srand(time(NULL));
  n = rand() % 1000 + 1;
  r = n+1;
  while (r != n)
    {
      c++;
      printf("Insira uma hipótese: ");
      scanf("%d", &r);
      if (n > r)
	printf("Maior\n");
      else if (n < r)
	printf("Menor\n");
    }
  printf("Ganhou em %d tentativas\n", c);

  return 0;
}
