#include <stdio.h>
#include <math.h>

//#define PI 3.1419

int main (void)
{
  float a;

  for (a = 0; a < 91.0; a += 10)
      printf("sin(%fº) = %f\n", a, sin((a/180.0)*M_PI));
  printf("\n");

  for (a = 0; a < 91.0; a += 10)
      printf("cos(%fº) = %f\n", a, cos((a/180.0)*M_PI));
  printf("\n");

  for (a = 0; a <= 15.0; a+= ((1.0/60) * 15.0))
    printf("tan(%fº) = %f\n", a, tan((a/180.0)*M_PI));

  return 0;
}
