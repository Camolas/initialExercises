#include <stdio.h>

#define TRUE 1
#define FALSE 0

int main (void)
{
  char c;
  int tag = FALSE;

  while ((c=getchar()) != EOF)
    {
      if (c == '<')
	tag = TRUE;
      else if (c == '>')
	{
	  tag = FALSE;
	  putchar(' ');
	}
      else if (!tag)
	putchar(c);
    }

  return 0;
}
