#include <stdio.h>
#include <math.h>

int main (void)
{
  float a,b,c;
  float x1, x2;
  
  printf("Insira os coeficientes (a b c): ");
  scanf("%f %f %f", &a, &b, &c);
  if (b*b - 4*a*c < 0)
    {
      printf("As raízes são complexas\n");
      x1 = (-b)/(a * 2);
      x2 = sqrt(-(b*b - 4*a*c));
      printf("x1 = %f + %fi | x2 = %f - %fi\n)", x1, x2, x1, x2);
    }
  else
    {
      printf("As raízes são reais\n");
      x1 = (-b + sqrt(b*b - 4*a*c))/(a * 2);
      x2 = (-b - sqrt(b*b - 4*a*c))/(a * 2);      
      printf("x1 = %f | x2 = %f\n", x1, x2);
    }

  return 0;
}
