#include <stdio.h>
#include <ctype.h>

int main (void)
{
  char c, num = 0, alfa = 0, total = 0;
  float media_num, media_alfa;

  while ((c=getchar()) != EOF)
    {
      if (isdigit(c)) num++;
      else if (isalpha(c)) alfa++;
      total++;
    }
  media_num = (float) num / total;
  media_alfa = (float) alfa / total;

  printf("%3.2f%% %3.2f%%\n", media_num*100, media_alfa*100);

  return 0;
}
