#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main (void)
{
  int p1, p2, r;  
  srand(time(NULL));
  while (1)
    {
      p1 = rand() % 10;
      p2 = rand() % 10;
      printf("Quanto é %d x %d? ",p1,p2);
      scanf("%d", &r);
      if (r == -1)
	break;
      else if (r == p1*p2)
	printf("Acertou!\n");
      else
	printf("Errado. A resposta correta era %d\n", p1*p2);
    }
  return 0;
}
