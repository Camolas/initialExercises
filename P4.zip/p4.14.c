#include <stdio.h>

#define TRUE 1
#define FALSE 0

int main (void)
{ 
  long long int a=0;
  char c;
  int r;

  while((c=getchar()) != '\n')
    {
      a *= 10;
      a += (c - '0');      
    }
  r = a % 10;
  a /= 10;
  
  if (a % 7 == r)
    printf("Válido\n");
  else
    printf("Inválido\n");
  
  return 0;
}
