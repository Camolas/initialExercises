#include <stdio.h>

int digito_decimal(int n, int k);

int main (void)
{
  int a, k;
  scanf("%d %d", &a, &k);
  printf("%d\n", digito_decimal(a,k));
  return 0;
}

int digito_decimal(int n, int k)
{
  int c, n1;
  for (c = 1, n1 = n; n1 > 0; n1 /= 10, c++);
  if (k > c - 1)
    return -1;
  for (c = 1, n1 = n; c < k; c++) n1 /= 10;
  return n1 % 10;
}
