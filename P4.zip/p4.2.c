#include <stdio.h>

int main (void)
{
  float a = 0.0;
  int i;
  for (i = 1; i < 1001; i++)
    {
      if (i % 2)
	a += 1.0/(2*i - 1);
      else
	a -= 1.0/(2*i - 1);
      if (i % 100 == 0)
	printf("%d - %f\n", i, 4.0*a);
    }
}
