#include <stdio.h>
#include <math.h>

double taylor_e(float x, int n);
double taylor_sin(float x, int n);
double taylor_cos(float x, int n);

int main (void)
{
  int n;
  float x;
  printf("Insira o x: ");
  scanf("%f", &x);
  printf("Insira n: ");
  scanf("%d", &n);
  printf("e^%f = %f %f (math.h)\n", x, taylor_e(x, n), exp(x));
  printf("sin %f = %f %f (math.h)\n", x, taylor_sin(x, n), sin(x));
  printf("cos %f = %f %f (math.h)\n", x, taylor_cos(x, n), cos(x));
 
  return 0;
}

double taylor_e (float x, int n)
{
  int i;
  double t = 1, s = 1;
  for (i = 1; i <= n; i++)
    {
      t *= x;
      t /= i;
      s += t;
    }
  return s;
}

double taylor_sin(float x, int n)
{
  int i;
  double t = x, s = x;
  for (i = 2; i < n; i++)
    {
      t *= x*x;
      t /= (double) ((2*i-1)*(2*i-2));
      if (i % 2)
	s += t;
      else
	s -= t;
    }
  return s;
}

double taylor_cos(float x, int n)
{
  int i;
  double t = 1, s = 1;
  for (i = 2; i <= n; i++)
    {
      t *= x*x;
      t /= (2*(i-1)*(2*(i-1)-1));
      if (i % 2)
	s += t;
      else
	s -= t;
    }
  return s;
}
