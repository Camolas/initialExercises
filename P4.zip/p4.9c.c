#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define EXIT 0
#define USER_ASK 1
#define CPU_ASK 2

int cli(void);
void user_ask(void);
void cpu_ask(void);

int main (void)
{
  int response = 3;
  while (response)
    {
      response = cli();
      switch (response)
	{
	case USER_ASK: user_ask(); break;
	case CPU_ASK: cpu_ask(); break;
	}
    }

  return 0;
}

void user_ask(void)
{
  int n, r, c = 0;
  srand(time(NULL));
  n = rand() % 1000 + 1;
  r = n+1;
  while (r != n)
    {
      c++;
      printf("Insira uma hipótese: ");
      scanf("%d", &r);
      if (n > r)
	printf("Maior\n");
      else if (n < r)
	printf("Menor\n");
    }
  printf("Ganhou em %d tentativas\n", c);
}

void cpu_ask(void)
{
  int n, max = 1000, min = 0, r, c = 0;
  printf("Insira n: ");
  scanf("%d", &n);
  r = 0;
  while (r != n) 
    {
      c++;     
      if (r > n)
	max = r - 1;
      else if (r < n)
	min = r + 1; 
      r = (max + min)/2;     
    }

  printf("n é %d\nganhei em %d tentativas\n", r, c);
}

int cli(void)
{
  int a;
  printf("Jogos - menu\n");
  printf("1 | Utilizador tenta adivinhar\n");
  printf("2 | PC tenta adivinhar\n");
  printf("0 | Sair\n\n");
  printf("Opção: ");
  scanf("%d", &a);
  return a;
}
