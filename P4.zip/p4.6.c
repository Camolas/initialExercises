#include <stdio.h>

int verifica(int x, int y, int n);

int main (void)
{
  int x, y, n;
  printf("Insira os valores (x y n): ");
  scanf("%d %d %d", &x, &y, &n);
  if (verifica(x,y,n))
    printf("%d e %d estão entre 0 e %d\n", x, y, n-1);

  return 0;
}

int verifica(int x, int y, int n)
{
  if (x >= 0 && x <= n-1 & y >= 0 && y <= n-1)
    return 1;
  return 0;
}
