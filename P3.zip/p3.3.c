#include <stdio.h>

int main (void)
{
  int p_c = 0, ig_c = 0, big, div_c = 0, mul_c = 0, n, n1;

  scanf("%d", &n);
  if (n % 2 == 0)
    p_c++;
  
  big = n;
  n1 = n;

  scanf("%d", &n);
  while (n != 0)
    {
      if (n % 2 == 0)
	p_c++;
      if (n == n1)
	ig_c++;
      if (n > big)
	big = n;
      if (n1 % n == 0)
	div_c++;
      if (n % n1 == 0)
	mul_c++;
      scanf("%d", &n);
    }

  printf("a) %d\n", p_c);
  printf("b) %d\n", ig_c);
  printf("c) %d\n", big);
  printf("d) %d\n", div_c);
  printf("e) %d\n", mul_c);

  return 0;
}
