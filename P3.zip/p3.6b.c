#include <stdio.h>

unsigned int base_conv(unsigned int num, unsigned int base);
int max_1(int num);

int main (void)
{
  unsigned int n, b;
  printf("Insira o número a converter: ");
  scanf("%d", &n);
  printf("Insira a base pretendida: ");
  scanf("%d", &b);

  n = base_conv(n, b);

  printf("%u\n", n);
  
  printf("O número máximo de 1's consecutivos é: %d\n", max_1(n));
    
  return 0;
}

unsigned int base_conv(unsigned int num, unsigned int base)
{
  unsigned int val = 0;
  unsigned int mult = 1;
  while (num > 0)
    {
      val += mult * (num % base);
      num /= base;
      mult *= 10;
    }
  //  val += mult * ((num % 10) % base);
  return val;
}

int max_1(int num)
{
  int c = 0;
  int max = 0;
  while (num > 0)
    {
      if (num % 10 == 1)
	c++;
      else
	{
	  if (c > max) max = c;
	  c = 0;
	}
      num /= 10;
    }
  
  if (c > max) max = c;
  return max;
}
