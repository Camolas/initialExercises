#include <stdio.h>

int main (void)
{
  float s, m;
  printf("Insira o saldo inicial: ");
  scanf("%f", &s);
  
  printf("%12.2f\n", s);
  scanf("%f", &m);
  while (m != 0.0)
    {
      s += m;
      if (s < 0)
	printf("%12.2f\n (Negativo)", s);
      else
	printf("%12.2f\n", s);
      scanf("%f", &m);
    }

  printf("\nSaldo final: %.2f\n", s);
  
  return 0;
}
