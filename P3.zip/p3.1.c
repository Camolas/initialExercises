#include <stdio.h>

int main (void)
{
  int tab[10][3];
  int i;
  for (i = 0; i < 10; i++)
    {
      tab[i][0] = i + 1;
      tab[i][1] = tab[i][0] * tab[i][0];
      tab[i][2] = tab[i][1] * tab[i][0];
    }

  for (i = 0; i < 10; i++)
    printf("%5d|%5d|%5d\n", tab[i][0], tab[i][1], tab[i][2]);
  return 0;
}
