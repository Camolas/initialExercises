#include <stdio.h>

int main (void)
{
  int x,y,n,i;
  int m1, m2, maior_s, maior_d, mul_c = 0;
  printf("Insira o número de pares: ");
  scanf("%d", &n);
  
  scanf("%d %d", &x, &y);
  m1 = x;
  m2 = y;
  maior_s = x + y;
  maior_d = x - y;
  
  if ((x + y) % 3 == 0)
    mul_c++;
  
  for (i = 1; i<n; i++)
    {
      scanf("%d %d", &x, &y);
      if (x > m1 || (x == m1 && y > m2))
	{
	  m1 = x;
	  m2 = y;
	}
	
      if ((x + y) > maior_s)
	maior_s = x + y;

      if ((x + y) % 3 == 0)
	mul_c++;
 
      if ((x - y) > maior_d)
	maior_d = x - y;
    }

  printf("a) %d %d\n", m1, m2);
  printf("b) %d\n", maior_s);
  printf("c) %d\n", mul_c);
  printf("d) %d\n", maior_d);

  return 0;
}
