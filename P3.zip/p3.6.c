#include <stdio.h>

unsigned int base_conv(unsigned int num, unsigned int base);

int main (void)
{
  unsigned int n, b;
  printf("Insira o número a converter: ");
  scanf("%d", &n);
  printf("Insira a base pretendida: ");
  scanf("%d", &b);

  n = base_conv(n, b);

  printf("%u\n", n);

  return 0;
}

unsigned int base_conv(unsigned int num, unsigned int base)
{
  unsigned int val = 0;
  unsigned int mult = 1;
  while (num > 0)
    {
      val += mult * (num % base);
      num /= base;
      mult *= 10;
    }
  return val;
}

