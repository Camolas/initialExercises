#include <stdio.h>

int main (void)
{
  int i;
  printf("Decimal | Octal | Hex\n");
  for (i = 0; i < 257; i++)
    {
      printf("%7d | %5o | %3x\n", i,i,i);
    }
  return 0;
}
