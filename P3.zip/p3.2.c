#include <stdio.h>

#define WIDTH 80

int main (void)
{
  int n, i;
  
  printf("Insira o valor de n: ");
  scanf("%d", &n);
  
  for (i = 1; i <= n; i++)
    {
      printf("*");
      if (i % WIDTH == 0)
	printf("\n");
    }
  if ((i - 1) % WIDTH != 0)
    printf("\n");
  return 0;
}
