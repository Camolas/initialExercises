#include <stdio.h>

unsigned int base_conv(unsigned int num, unsigned int base);
int soma_dig(int num);

int main (void)
{
  unsigned int n, b;
  printf("Insira o número a converter: ");
  scanf("%d", &n);
  printf("Insira a base pretendida: ");
  scanf("%d", &b);

  n = base_conv(n, b);

  printf("%u\n", n);
  
  if (soma_dig(n) % 2 == 0)
    printf("A soma dos dígitos desta representação é par.\n");
  
  return 0;
}

unsigned int base_conv(unsigned int num, unsigned int base)
{
  unsigned int val = 0;
  unsigned int mult = 1;
  while (num > 0)
    {
      val += mult * (num % base);
      num /= base;
      mult *= 10;
    }
  return val;
}

int soma_dig(int num)
{
  int c = 0;
  while (num > 0)
    {
      c += num % 10;
      num /= 10;
    }
  return c;
}
