#include <stdio.h>

#define IN_CM 2.54
#define FT_M 0.3048
#define LB_KG 0.45359
#define GL_L 3.7854

int main (void)
{
  float u, u1, conv;
  char c;
  char clr[] = {0x1b, 0x5b, 0x48, 0x1b, 0x5b, 0x4a, '\0'}; //http://www.tek-tips.com/viewthread.cfm?qid=76828

  printf(clr);
  printf("Super programa 3000 conversor\n\n");
  for(;;)
    {
      printf("|----------|-------------|-------|\n");
      printf("| Unidade  |  Resultado  | Opção |\n");
      printf("|----------|-------------|-------|\n");
      printf("| Polegada | Centímetro  |   1   |\n");
      printf("|   Pés    |    Metros   |   2   |\n");
      printf("|  Libras  | Quilogramas |   3   |\n");
      printf("|  Galões  |    Litros   |   4   |\n");
      printf("|----------|-------------|-------|\n");
      printf("\nOpção (0 para sair): ");
      c = getchar();
      while(getchar() != '\n');
      if (c == '0') break;
      switch(c)
	{
	case '1':
	  conv = IN_CM;
	  break;
	case '2':
	  conv = FT_M;
	  break;
	case '3':
	  conv = LB_KG;
	  break;
	case '4':
	  conv = GL_L;
	  break;
	default:
	  printf(clr);
	  printf("Opção inválida\n");
	  continue;
	}
      printf("Insira valor a converter: ");
      scanf("%f", &u);
      u1 = conv * u;
      printf("Convertido: %f\n", u1);
      printf("Prima enter para continuar");
      getchar();
      while(getchar() != '\n');
      printf(clr);
    }
  return 0;
}
